document.addEventListener('DOMContentLoaded', function() {
  var calculateButton = document.getElementById('calculateButton');
  if (calculateButton) {
    calculateButton.addEventListener('click', function() {
      var num1 = parseFloat(document.getElementById('num1').value);
      var num2 = parseFloat(document.getElementById('num2').value);
      var operation = document.getElementById('operation').value;
      var resultElement = document.getElementById('result');

      var result;
      if (operation === '+') {
        result = num1 + num2;
      } else if (operation === '-') {
        result = num1 - num2;
      } else if (operation === '*') {
        result = num1 * num2;
      } else if (operation === '/') {
        if (num2 !== 0) {
          result = num1 / num2;
        } else {
          resultElement.textContent = 'Error: division by zero!';
          return;
        }
      } else {
        resultElement.textContent = 'Error: invalid operation!';
        return;
      }

      resultElement.textContent = 'Result: ' + result;
    });
  }
});
